Karma logo kit: Seed 2, "Twin"
================================

The mark is a sunflower of dots with two spiral grooves. It has two drawings, like a type family:
  * dotted  from 64 px tall and up (the colourful gradient, made of dots)
  * solid   below 64 px (the app header, tabs, icons), where dots would blur

svg/  (plain shapes, no fonts needed; every file has a viewBox, so it scales freely)
  karma-lockup.svg / -reversed.svg                mark + name, the main logo, for light / dark grounds. 64 px tall and up.
  karma-lockup-solid.svg / -reversed.svg          the same below 64 px: app header, small placements.
  karma-mark.svg / -reversed.svg                  the dotted mark alone.
  karma-mark-solid.svg / -solid-reversed.svg      the solid mark alone.
  karma-mark-mono.svg                             one colour: it takes the text colour of whatever it sits in (fill = currentColor).
  karma-wordmark.svg / -reversed.svg              the name alone.
  karma-icon.svg                                  the tab and app icon: the solid mark on a rounded carbon square.

Root files for a website (copy them to the site's public folder):
  favicon.svg  favicon.ico (16, 32, 48)  favicon-16x16.png  favicon-32x32.png  favicon-48x48.png
  apple-touch-icon.png (180)  icon-192.png  icon-512.png

In the page <head>:
  <link rel="icon" href="/favicon.ico" sizes="48x48">
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">

Rules
  * Clear space on every side: the height of the "k" in the name.
  * Never recolour the dots, stretch the mark, or retype the name: use the files.
  * On dark grounds use the -reversed files (pale name, dots that cool from white to blue).
